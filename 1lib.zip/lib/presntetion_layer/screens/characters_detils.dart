import 'package:flutter/cupertino.dart';

class CharactersDetils extends StatelessWidget {
  const CharactersDetils({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
