final baseUrl ='https://www.breakingbadapi.com/api/';
const allCharactersRoute='/';
const charactoreDetilsSceens = '/character_details';