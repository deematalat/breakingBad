
import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';

part 'char_state.dart';

class CharCubit extends Cubit<CharState> {
  CharCubit() : super(CharInitial());
}
