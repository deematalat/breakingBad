
 import 'package:flutter/material.dart';
import 'package:untitled1/presntetion_layer/screens/characters_detils.dart';
import 'package:untitled1/presntetion_layer/screens/characters_screens.dart';
class AppRouter {
     Route ? generateRoute(RouteSettings settings){
             switch(settings.name){
               case 'allCharactersRoute':
                 return  MaterialPageRoute(builder: (_)=>CharactersScreen());
               case ' charactoreDetilsSceens':
                 return MaterialPageRoute(builder: (_)=>CharactersDetils());

             }

     }
      }

